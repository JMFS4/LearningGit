/* 
Usando o operador sizeof(), calcule o espaço em memória ocupado pela estrutura que usou no exercício 
anterior e a média de cada célula do array; 
*/

#include<stdio.h> ??
#define nrTrabalhadores 5
int salarios[nrTrabalhadores];
int main()
{
   printf("O tamanho, em bytes, do array salarios e %d", ???);
   printf("\nCada celula ou posicao do array ocupa %d bytes",?????;

}
