/*
Crie em C um programa que leia 4 valores reais para  um array, correspondendo a 4 notas de uma turma e 
calcule a sua média e o número de aprovações. Crie 3 funções: uma para input de dados, outra para o calcula da média e 
outra para o número de aprovações;
*/
#include<stdio.h>
#define nrAlunos 4
float notas[nrAlunos];
void lerNotas()
{
    for(int i = 0 ; ????; i ++ )
    {
        ///???
        scanf("%f", &notas[i]);
    }
    printf("\nObrigado");
}
float mediaNotas()
{
    float soma = 0;
     ///???
}

int alunosAprovados()
{
    int aprovados = 0;
    ///????
    return aprovados;
}
int main( )
{
    lerNotas();
    printf("A media da turma e %.2f",????);
    printf("\nO numero de alunos aprovados e de %d \n", ????);

}
