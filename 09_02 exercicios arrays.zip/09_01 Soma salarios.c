/* 
programa que considere 5 valores inteiros: 1300, 1000, 950, 2050, 1150 , correspondendo a 5 salários de uma PME 
e calcule a sua soma (despesa com salários da PME) e a sua média;
*/

#include<stdio.h>
#define nrTrabalhadores 5
int salarios[nrTrabalhadores] = ????
/// @brief função que calcula a soma dos salários de uma empresa 
/// @return a soma dos salarios usando valores de array declarado como variável global
int somaSalarios()
{ 
    int soma= 0;
    for(int i = 0;  i < nrTrabalhadores; i ++ )
     
}
int main()
{
   printf(" A soma dos salarios da PME e %d", ?????);
   printf(" A media dos salarios da PME e %.2f", ?????+.0);

}
